import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { extractFromText } from "@/lib/text-extractor";

export async function GET(request: NextRequest) {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });

  const sessionId = request.nextUrl.searchParams.get("sessionId");
  if (!sessionId) return NextResponse.json({ error: "sessionId required" }, { status: 400 });

  const { data, error } = await supabase
    .from("tax_records")
    .select("*")
    .eq("session_id", sessionId)
    .order("created_at", { ascending: false });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data);
}

// Body: { sessionId, rawText, categoryCode? }
// Free-text input path — extraction happens server-side so the client never
// has to embed classification logic.
export async function POST(request: NextRequest) {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });

  const body = await request.json();
  const { sessionId, rawText, categoryCode } = body;

  if (!sessionId || !rawText) {
    return NextResponse.json({ error: "sessionId and rawText required" }, { status: 400 });
  }

  const extracted = extractFromText(rawText);

  const { data, error } = await supabase
    .from("tax_records")
    .insert({
      session_id: sessionId,
      source: "text",
      raw_input: rawText,
      extracted,
      category_code: categoryCode ?? null,
      status: categoryCode ? "candidate" : "unknown",
      confidence: categoryCode ? 0.6 : 0
    })
    .select()
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data);
}

// Body: { recordId, status, categoryCode? }
// Used to confirm a candidate record, exclude it, or reclassify it.
export async function PATCH(request: NextRequest) {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });

  const body = await request.json();
  const { recordId, status, categoryCode } = body;

  const updatePayload: Record<string, unknown> = {};
  if (status) updatePayload.status = status;
  if (categoryCode) updatePayload.category_code = categoryCode;

  const { data, error } = await supabase
    .from("tax_records")
    .update(updatePayload)
    .eq("id", recordId)
    .select()
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data);
}
