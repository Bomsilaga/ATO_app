import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { answerNode } from "@/lib/triage-engine";

export async function GET(request: NextRequest) {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });

  const financialYear = request.nextUrl.searchParams.get("fy");
  if (!financialYear) return NextResponse.json({ error: "fy required" }, { status: 400 });

  const { data, error } = await supabase
    .from("tax_sessions")
    .select("*")
    .eq("user_id", user.id)
    .eq("financial_year", financialYear)
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 404 });
  return NextResponse.json(data);
}

// Body: { sessionId, code, applies, notes? }
export async function PATCH(request: NextRequest) {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });

  const body = await request.json();
  const { sessionId, code, applies, notes } = body;

  const { data: session, error: fetchError } = await supabase
    .from("tax_sessions")
    .select("*")
    .eq("id", sessionId)
    .eq("user_id", user.id)
    .single();

  if (fetchError || !session)
    return NextResponse.json({ error: "session not found" }, { status: 404 });

  const updatedState = answerNode(session.triage_state, code, applies, notes);

  const { data, error } = await supabase
    .from("tax_sessions")
    .update({ triage_state: updatedState, updated_at: new Date().toISOString() })
    .eq("id", sessionId)
    .select()
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data);
}
