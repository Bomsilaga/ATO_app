"use client";

import { useEffect, useState, useCallback } from "react";
import { useParams } from "next/navigation";
import { TaxSession, TaxRecord } from "@/lib/types";
import { nextTriageBatch, isTriageComplete } from "@/lib/triage-engine";
import CategoryTriage from "@/components/CategoryTriage";
import FileUpload from "@/components/FileUpload";
import RecordList from "@/components/RecordList";
import PrefillReport from "@/components/PrefillReport";

export default function SessionPage() {
  const params = useParams();
  const fy = params.fy as string;

  const [session, setSession] = useState<TaxSession | null>(null);
  const [records, setRecords] = useState<TaxRecord[]>([]);
  const [textInput, setTextInput] = useState("");
  const [prefill, setPrefill] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [guidanceLoading, setGuidanceLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadSession = useCallback(async () => {
    const res = await fetch(`/api/sessions?fy=${fy}`);
    if (res.ok) setSession(await res.json());
  }, [fy]);

  const loadRecords = useCallback(async () => {
    if (!session) return;
    const res = await fetch(`/api/records?sessionId=${session.id}`);
    if (res.ok) setRecords(await res.json());
  }, [session]);

  useEffect(() => {
    loadSession().finally(() => setLoading(false));
  }, [loadSession]);

  useEffect(() => {
    if (session) loadRecords();
  }, [session, loadRecords]);

  function handleAnswered(code: string, applies: boolean) {
    setSession((prev) =>
      prev
        ? {
            ...prev,
            triage_state: prev.triage_state.map((n) =>
              n.code === code ? { ...n, state: "asked_and_answered", applies } : n
            )
          }
        : prev
    );
  }

  async function submitText() {
    if (!session || !textInput.trim()) return;
    await fetch("/api/records", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId: session.id, rawText: textInput })
    });
    setTextInput("");
    loadRecords();
  }

  async function fetchGuidance() {
    if (!session) return;
    setGuidanceLoading(true);
    setError(null);
    const res = await fetch("/api/guidance", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId: session.id })
    });
    const data = await res.json();
    setGuidanceLoading(false);
    if (!res.ok) {
      setError(data.error);
      return;
    }
    loadSession();
  }

  async function generatePrefill() {
    if (!session) return;
    setError(null);
    const res = await fetch("/api/prefill", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId: session.id })
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error);
      return;
    }
    setPrefill(data);
  }

  if (loading) return <main className="p-12 text-sm text-ink/60">Loading…</main>;
  if (!session) return <main className="p-12 text-sm text-flag">Session not found.</main>;

  const triageComplete = isTriageComplete(session.triage_state);
  const batch = nextTriageBatch(session.triage_state);

  return (
    <main className="min-h-screen px-6 py-12 max-w-3xl mx-auto space-y-10">
      <header>
        <span className="code-tag">FY {session.financial_year}</span>
        <h1 className="ledger-heading text-2xl font-semibold mt-2">
          {triageComplete ? "Records & pre-fill" : "Triage sweep"}
        </h1>
      </header>

      {!triageComplete && (
        <section className="border border-line p-6 bg-white/40">
          <p className="text-sm text-ink/60 mb-6">
            Answer plainly — every category gets asked, nothing is assumed from your
            occupation or income type.
          </p>
          <CategoryTriage sessionId={session.id} batch={batch} onAnswered={handleAnswered} />
        </section>
      )}

      {triageComplete && (
        <>
          <section className="border border-line p-6 bg-white/40 space-y-4">
            <h2 className="ledger-heading text-lg font-semibold">Add a record</h2>
            <textarea
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              placeholder="e.g. Sold my car for $8,000 in March 2026"
              rows={2}
              className="w-full border border-line p-3 text-sm bg-transparent outline-none focus:border-ledger"
            />
            <button
              onClick={submitText}
              className="px-4 py-1.5 text-xs font-mono uppercase tracking-wide border border-ledger text-ledger hover:bg-ledger hover:text-paper"
            >
              Add
            </button>
            <FileUpload sessionId={session.id} onUploaded={loadRecords} />
          </section>

          <section className="border border-line p-6 bg-white/40">
            <h2 className="ledger-heading text-lg font-semibold mb-4">Records</h2>
            <RecordList records={records} onChanged={loadRecords} />
          </section>

          <section className="border border-line p-6 bg-white/40 space-y-3">
            <h2 className="ledger-heading text-lg font-semibold">Live guidance & pre-fill</h2>
            <p className="text-sm text-ink/60">
              Fetches current ATO thresholds and rulings for your active categories, then
              generates a label-mapped pre-fill from your confirmed records.
            </p>
            <div className="flex gap-3">
              <button
                onClick={fetchGuidance}
                disabled={guidanceLoading}
                className="px-4 py-2 text-xs font-mono uppercase tracking-wide border border-ledger text-ledger hover:bg-ledger hover:text-paper disabled:opacity-50"
              >
                {guidanceLoading ? "Fetching…" : "Fetch current ATO guidance"}
              </button>
              <button
                onClick={generatePrefill}
                className="px-4 py-2 text-xs font-mono uppercase tracking-wide border border-line text-ink/70 hover:border-ink hover:text-ink"
              >
                Generate pre-fill
              </button>
            </div>
            {error && <p className="text-sm text-flag">{error}</p>}
          </section>

          {prefill && (
            <PrefillReport
              labels={prefill.labels}
              summary={prefill.plain_english_summary}
              agentFlags={prefill.agent_review_flags}
              disclaimer={prefill.disclaimer}
            />
          )}
        </>
      )}
    </main>
  );
}
