"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { initTriageState } from "@/lib/triage-engine";

function currentAuFinancialYear(): string {
  const now = new Date();
  const year = now.getMonth() >= 6 ? now.getFullYear() : now.getFullYear() - 1; // FY starts July
  return `${year}-${String((year + 1) % 100).padStart(2, "0")}`;
}

function recentFinancialYears(count = 5): string[] {
  const [startYear] = currentAuFinancialYear().split("-");
  const start = parseInt(startYear, 10);
  return Array.from({ length: count }, (_, i) => {
    const y = start - i;
    return `${y}-${String((y + 1) % 100).padStart(2, "0")}`;
  });
}

export default function FinancialYearPicker({ userId }: { userId: string }) {
  const [selected, setSelected] = useState(currentAuFinancialYear());
  const [occupation, setOccupation] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const supabase = createClient();

  async function startSession() {
    setLoading(true);
    const { data, error } = await supabase
      .from("tax_sessions")
      .upsert(
        {
          user_id: userId,
          financial_year: selected,
          occupation: occupation || null,
          triage_state: initTriageState(),
          status: "in_progress"
        },
        { onConflict: "user_id,financial_year" }
      )
      .select()
      .single();

    setLoading(false);
    if (!error && data) {
      router.push(`/session/${selected}`);
    }
  }

  return (
    <div className="border border-line p-6 bg-white/40">
      <h2 className="ledger-heading text-xl font-semibold mb-4">Start or resume a return</h2>

      <label className="text-xs font-mono uppercase tracking-wide text-ink/60">
        Financial year
      </label>
      <select
        value={selected}
        onChange={(e) => setSelected(e.target.value)}
        className="mt-1 mb-4 w-full bg-transparent border-b border-line py-2 outline-none focus:border-ledger"
      >
        {recentFinancialYears().map((fy) => (
          <option key={fy} value={fy}>
            {fy}
          </option>
        ))}
      </select>

      <label className="text-xs font-mono uppercase tracking-wide text-ink/60">
        Occupation (used to prompt occupation-specific deductions)
      </label>
      <input
        type="text"
        value={occupation}
        onChange={(e) => setOccupation(e.target.value)}
        placeholder="e.g. Civil Project Manager"
        className="mt-1 mb-6 w-full bg-transparent border-b border-line py-2 outline-none focus:border-ledger"
      />

      <button
        onClick={startSession}
        disabled={loading}
        className="w-full bg-ledger text-paper py-2.5 text-sm font-medium tracking-wide hover:bg-ledgerLight transition-colors disabled:opacity-50"
      >
        {loading ? "Starting…" : `Begin triage for ${selected}`}
      </button>
    </div>
  );
}
