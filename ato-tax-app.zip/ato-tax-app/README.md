# ATO Triage

A tax-return preparation tool that takes plain text, file uploads, or CSV exports (crypto
exchanges, bank statements), triages every ATO income/deduction/offset category without assuming
what you do or don't own, and produces a label-mapped pre-fill using **live** ATO guidance fetched
fresh each session — not a static dataset that goes stale.

This is a preparation aid, not a lodgement service and not tax advice. It flags categories
(capital gains, rental property, foreign income, business income) where a registered tax agent
should review before you lodge.

## What's inside

```
lib/
  types.ts                 Domain types — records, categories, sessions, CGT lots
  taxonomy.ts               Full ATO category tree (Q1-24, D1-15, T1-9), mapped to real labels
  triage-engine.ts          Zero-assumption triage state machine
  text-extractor.ts         Free-text → structured record extraction
  csv-normalizer.ts         Exchange/bank CSV format detection + normalization
  cgt-engine.ts             Crypto cost-base ledgers, FIFO disposal matching, discount test
  guidance-fetcher.ts       Live Claude API + web search call for current ATO guidance
  deduction-maximizer.ts    Flags likely-unclaimed deductions (never auto-adds them)
  prefill-generator.ts      Final label-mapped output + agent-review flags
  supabase/                 Browser + server Supabase clients

app/
  login/                    Magic-link auth
  dashboard/                Financial year picker + session list
  session/[fy]/             Main triage → records → guidance → pre-fill flow
  api/                      Route handlers: sessions, records, upload, guidance, prefill

supabase/schema.sql          Full Postgres schema with row-level security
```

## 1. Local setup

```bash
npm install
cp .env.example .env.local
```

Fill in `.env.local`:

| Variable | Where to get it |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase project → Settings → API |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Same page |
| `SUPABASE_SERVICE_ROLE_KEY` | Same page (only needed if you later add server-only admin actions) |
| `ANTHROPIC_API_KEY` | console.anthropic.com → API Keys |

## 2. Create the Supabase project

1. Go to [supabase.com](https://supabase.com) → New project.
2. Once created, open the SQL editor and paste the contents of `supabase/schema.sql`, then run it.
3. In **Authentication → Providers**, ensure Email (magic link) is enabled — it is by default.
4. In **Authentication → URL Configuration**, add your local and production URLs to the redirect
   allow-list, e.g.:
   - `http://localhost:3000/auth/callback`
   - `https://<your-vercel-domain>/auth/callback`

## 3. Run locally

```bash
npm run dev
```

Visit `http://localhost:3000` — you'll be redirected to `/login`, sent a magic link, and land on
`/dashboard` after clicking it.

## 4. Push to GitHub

```bash
git init
git add .
git commit -m "Initial ATO triage app"
git branch -M main
git remote add origin https://github.com/<your-username>/ato-triage.git
git push -u origin main
```

## 5. Deploy to Vercel

1. Go to [vercel.com/new](https://vercel.com/new) and import the GitHub repo you just pushed.
2. Framework preset: Next.js (auto-detected).
3. Add the same four environment variables from `.env.local` under **Settings → Environment
   Variables** (for Production, Preview, and Development).
4. Deploy. Once live, go back to Supabase **Authentication → URL Configuration** and add your real
   Vercel domain's `/auth/callback` URL to the redirect allow-list — magic links won't work until
   you do this.

## How the "live guidance" piece works

Every time you click **Fetch current ATO guidance** in a session, the app calls the Anthropic API
(`lib/guidance-fetcher.ts`) with web search enabled, scoped to exactly the categories your triage
answers activated for that financial year. The result is stored against that session only —
nothing is cached globally or reused across financial years, because thresholds and rulings change
every year and sometimes mid-year (see the README note in `lib/guidance-fetcher.ts` for why this
matters).

## Extending it

- **Exchange APIs (read-only)**: add a new module under `lib/` following the pattern in
  `csv-normalizer.ts` — each exchange gets a signature/mapper, then a scheduled or on-demand pull
  populates `tax_records` the same way CSV upload does now.
- **New CSV formats**: add a new entry to `FORMAT_SIGNATURES` in `lib/csv-normalizer.ts`.
- **New ATO categories or a new financial year's label changes**: update `lib/taxonomy.ts` — this
  is the single source of truth the triage engine, classifier, and pre-fill generator all read
  from.

## Known limitations (v0.1)

- OCR for photographed receipts isn't wired up yet — PDF text extraction works, but image-only
  receipts need a vision step added to `app/api/upload/route.ts`.
- Exchange API pulls (CoinSpot/Binance/etc. read-only keys) are designed for but not yet
  implemented — CSV upload is the current path.
- The classifier that assigns a category to free-text/CSV records is currently manual (you pick
  the label from a dropdown in the Records list) — an automatic first-pass classifier using the
  Anthropic API is a natural next addition alongside the guidance fetcher.
